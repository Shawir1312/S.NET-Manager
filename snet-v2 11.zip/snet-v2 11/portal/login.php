<?php
define('IN_APP',true);
require_once __DIR__.'/../includes/config.php';
if(isCust()){header('Location: /portal/index.php');exit;}

$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    csrfVerify();
    $cid=strtoupper(trim($_POST['customer_id']??''));$pw=$_POST['password']??'';
    if($cid&&$pw){
        // Rate limiting
        if(!checkLoginRateLimit($cid,'portal')){
            $left=LOGIN_LOCKOUT_MINS;
            $err="Terlalu banyak percobaan login. Coba lagi setelah $left menit.";
        } else {
            $s=db()->prepare("SELECT * FROM customers WHERE customer_id=? AND is_active=1 LIMIT 1");
            $s->execute([$cid]);$c=$s->fetch();
            if($c&&password_verify($pw,$c['password'])){
                clearLoginAttempts($cid,'portal');
                // Fix session fixation
                session_regenerate_id(true);
                $_SESSION['cust_id']=$c['id'];$_SESSION['cust_cid']=$c['customer_id'];
                $_SESSION['cust_name']=$c['full_name'];$_SESSION['cust_device_id']=$c['genie_device_id'];
                auditLog('portal_login',$c['customer_id'],'','customer');
                header('Location: /portal/index.php');exit;
            } else {
                recordLoginAttempt($cid,'portal');
                $left=loginAttemptsLeft($cid,'portal');
                $err='ID Pelanggan atau password salah!'.($left>0?" (Sisa $left percobaan)":" — Akun dikunci ".LOGIN_LOCKOUT_MINS." menit.");
            }
        }
    } else {$err='Harap isi ID dan password!';}
}
if(isset($_GET['err'])&&$_GET['err']==='disabled')$err='Akun Anda tidak aktif. Hubungi admin S.NET.';
$_csrf=csrfToken();
$logo=logoB64();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Portal Pelanggan — S.NET</title>
<link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@600&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--red:#D42B2B;--blue:#1B3FA6;--blue-d:#122B7A;--g50:#F8FAFF;--g100:#F0F3FA;--g200:#E0E6F5;--g400:#8A95B8;--g700:#3A4468}
body{font-family:'Exo 2',sans-serif;min-height:100vh;background:var(--g50);display:flex;flex-direction:column}
.bg{position:fixed;inset:0;background:linear-gradient(135deg,#0D1B5E 0%,var(--blue-d) 45%,#8B1414 100%);z-index:0}
.bg::before{content:'';position:absolute;top:-200px;right:-200px;width:600px;height:600px;border-radius:50%;border:1px solid rgba(255,255,255,.05)}
.bg::after{content:'';position:absolute;bottom:-200px;left:-200px;width:700px;height:700px;border-radius:50%;border:1px solid rgba(255,255,255,.05)}
.wrap{position:relative;z-index:1;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px}
.card{background:#fff;border-radius:20px;width:100%;max-width:420px;box-shadow:0 20px 60px rgba(18,43,122,.35);overflow:hidden}
.hero{background:linear-gradient(135deg,var(--blue-d),var(--blue));padding:28px 28px 22px;text-align:center;position:relative}
.hero::after{content:'';position:absolute;bottom:-1px;left:0;right:0;height:20px;background:#fff;clip-path:ellipse(55% 100% at 50% 100%)}
.hero img{max-width:180px;max-height:56px;object-fit:contain;filter:drop-shadow(0 4px 12px rgba(0,0,0,.3));margin-bottom:10px}
.hero-t{color:rgba(255,255,255,.72);font-size:.78rem;letter-spacing:.5px}
.body{padding:28px}
.t1{font-size:1.3rem;font-weight:800;color:var(--blue-d);margin-bottom:3px}
.t2{color:var(--g400);font-size:.82rem;margin-bottom:22px}
.fl{display:block;font-size:.7rem;font-weight:700;color:var(--g700);text-transform:uppercase;letter-spacing:1px;margin-bottom:5px}
.fc{width:100%;padding:11px 14px;border:2px solid var(--g200);border-radius:10px;font-family:'Exo 2',sans-serif;font-size:.92rem;color:var(--g700);background:var(--g50);transition:.2s;outline:none}
.fc:focus{border-color:var(--blue);background:#fff;box-shadow:0 0 0 4px rgba(27,63,166,.08)}
input.cid{font-family:'JetBrains Mono',monospace;text-transform:uppercase;font-size:1rem;letter-spacing:2px;font-weight:600;color:var(--blue-d)}
.fg{margin-bottom:16px}
.sbtn{width:100%;padding:13px;background:linear-gradient(135deg,var(--blue),var(--blue-d));color:#fff;border:none;border-radius:10px;font-family:'Exo 2',sans-serif;font-size:.95rem;font-weight:700;letter-spacing:1px;cursor:pointer;transition:.3s;margin-top:4px}
.sbtn:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(27,63,166,.4)}
.err{background:#FEE2E2;border-left:4px solid var(--red);color:#DC2626;padding:10px 14px;border-radius:8px;font-size:.84rem;margin-bottom:16px}
.foot{text-align:center;padding:14px 28px 20px;font-size:.75rem;color:var(--g400);border-top:1px solid var(--g100)}
</style>
</head>
<body>
<div class="bg"></div>
<div class="wrap">
<div class="card">
    <div class="hero">
        <?php if($logo):?><img src="<?=$logo?>" alt="S.NET"><?php else:?><div style="color:#fff;font-size:2rem;font-weight:900;margin-bottom:8px">S.NET</div><?php endif;?>
        <div class="hero-t">Portal Pelanggan — Self-Service WiFi</div>
    </div>
    <div class="body">
        <div class="t1">Masuk Portal</div>
        <div class="t2">Gunakan ID Pelanggan dari teknisi S.NET Anda</div>
        <?php if($err):?><div class="err">⚠️ <?=h($err)?></div><?php endif;?>
        <form method="POST">
            <?=csrfField()?>
            <div class="fg"><label class="fl">ID Pelanggan</label>
                <input type="text" name="customer_id" id="customer_id" class="fc cid" placeholder="SNET-0001" required autocomplete="username" value="<?=h(strtoupper($_POST['customer_id']??''))?>">
            </div>
            <div class="fg"><label class="fl">Password</label>
                <input type="password" name="password" class="fc" placeholder="••••••••" required autocomplete="current-password">
            </div>
            <button type="submit" class="sbtn">🚀 Masuk ke Portal</button>
        </form>
    </div>
    <div class="foot">Lupa password? Hubungi admin atau teknisi S.NET &bull; &copy; <?=date('Y')?> PT Network Inovation Solutions</div>
</div>
</div>
</body>
</html>
