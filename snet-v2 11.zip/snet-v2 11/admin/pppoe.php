<?php
define('IN_APP',true);
require_once __DIR__.'/../includes/config.php';
require_once __DIR__.'/../includes/layout.php';
requireAdmin();
$db=db();

// Load settings - handle case where table doesn't exist yet
$settings=[];
try{
    foreach($db->query("SELECT setting_key,setting_value FROM pppoe_settings") as $s)
        $settings[$s['setting_key']]=$s['setting_value'];
}catch(\Exception $e){
    // Table doesn't exist - show setup message
    startPage('PPPoE Manager');
    echo '<div class="card"><div class="cb" style="padding:30px;text-align:center">';
    echo '<div style="font-size:2rem;margin-bottom:12px">⚠️</div>';
    echo '<h3 style="margin-bottom:8px">Setup Database Diperlukan</h3>';
    echo '<p style="color:var(--g400);margin-bottom:16px">Tabel PPPoE belum ada. Jalankan perintah berikut di server:</p>';
    echo '<pre style="background:#1F2937;color:#F9FAFB;padding:12px;border-radius:6px;text-align:left;font-size:.8rem">mysql -u USER -p DBNAME &lt; /path/to/database.sql</pre>';
    echo '<p style="color:var(--g400);font-size:.8rem;margin-top:8px">Atau import file <strong>database.sql</strong> via phpMyAdmin/HeidiSQL.</p>';
    echo '</div></div>';
    endPage();
    exit;
}

$routers=$db->query("SELECT id,name,ip_public,host,port,username,password FROM routers WHERE is_active=1 ORDER BY is_main DESC,name")->fetchAll();
$selRid=(int)($_GET['rid']??($routers[0]['id']??0));
$selRouter=null;
foreach($routers as $r){if($r['id']==$selRid){$selRouter=$r;break;}}

$msg='';$mtype='ok';
$act=trim($_POST['action']??'');

// ── Handle POST actions ──────────────────────────────────
if($act==='save_settings'){
    $keys=['midtrans_server_key','midtrans_client_key','midtrans_mode','isolir_profile',
           'isolir_grace_days','company_name','company_phone','company_address'];
    foreach($keys as $k){
        $v=trim($_POST[$k]??'');
        $db->prepare("INSERT INTO pppoe_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=?")->execute([$k,$v,$v]);
    }
    $msg='✅ Pengaturan disimpan!';header("Location: /admin/pppoe.php?rid=$selRid&tab=settings&ok=1");exit;
}

if($act==='add_customer'&&$selRouter){
    $uname=trim($_POST['pppoe_username']??'');
    $name=trim($_POST['full_name']??'');
    $phone=trim($_POST['phone']??'');
    $address=trim($_POST['address']??'');
    $profile=trim($_POST['profile']??'');
    $price=(int)($_POST['monthly_price']??0);
    $due=(int)($_POST['due_day']??1);
    $password=trim($_POST['password']??'');
    if(!$uname||!$name){$msg='❌ Username dan nama wajib diisi!';$mtype='err';}
    else{
        // Tambah ke MikroTik juga jika password diisi
        if($password){
            $api=MikrotikAPI::fromRouter($selRouter);
            if($api->connect()){
                $cmd=['/ppp/secret/add','=name='.$uname,'=password='.$password,'=service=pppoe'];
                if($profile)$cmd[]='=profile='.$profile;
                $api->talk($cmd);$api->close();
            }
        }
        try{
            $db->prepare("INSERT INTO pppoe_customers(router_id,pppoe_username,full_name,phone,address,profile,monthly_price,due_day,created_by) VALUES(?,?,?,?,?,?,?,?,?)")
               ->execute([$selRid,$uname,$name,$phone,$address,$profile,$price,$due,$_SESSION['admin_id']??null]);
            $msg='✅ Pelanggan '.$name.' berhasil ditambahkan!';
        }catch(\Exception $e){$msg='❌ Username sudah ada di database!';$mtype='err';}
    }
}

if($act==='isolir'&&$selRouter){
    $cid=(int)($_POST['cid']??0);
    $reason=trim($_POST['reason']??'Jatuh tempo');
    $row=$db->prepare("SELECT * FROM pppoe_customers WHERE id=? AND router_id=?")->execute([$cid,$selRid])?$db->prepare("SELECT * FROM pppoe_customers WHERE id=? AND router_id=?")->execute([$cid,$selRid]):null;
    $cust=$db->prepare("SELECT * FROM pppoe_customers WHERE id=?");$cust->execute([$cid]);$cust=$cust->fetch();
    if($cust){
        $isoProfile=$settings['isolir_profile']??'isolir';
        $api=MikrotikAPI::fromRouter($selRouter);
        if($api->connect()){
            // Change profile ke isolir
            $api->talk(['/ppp/secret/set','?name='.$cust['pppoe_username'],'=profile='.$isoProfile]);
            // Putus sesi aktif
            $act2=$api->parse($api->talk(['/ppp/active/print','?name='.$cust['pppoe_username'],'=.proplist=.id']));
            foreach($act2 as $a){if(isset($a['.id']))$api->talk(['/ppp/active/remove','=.id='.$a['.id']]);}
            $api->close();
        }
        $db->prepare("UPDATE pppoe_customers SET status='isolated',isolated_at=NOW(),isolated_reason=? WHERE id=?")->execute([$reason,$cid]);
        auditLog('pppoe_isolir',$cust['pppoe_username'],$reason);
        $msg='✅ Pelanggan '.$cust['full_name'].' berhasil diisolir!';
    }
}

if($act==='reaktivasi'&&$selRouter){
    $cid=(int)($_POST['cid']??0);
    $cust=$db->prepare("SELECT * FROM pppoe_customers WHERE id=?");$cust->execute([$cid]);$cust=$cust->fetch();
    if($cust){
        $api=MikrotikAPI::fromRouter($selRouter);
        if($api->connect()){
            $profile=$cust['profile']?:'default';
            $api->talk(['/ppp/secret/set','?name='.$cust['pppoe_username'],'=profile='.$profile]);
            $api->close();
        }
        $db->prepare("UPDATE pppoe_customers SET status='active',isolated_at=NULL,isolated_reason='' WHERE id=?")->execute([$cid]);
        auditLog('pppoe_reaktivasi',$cust['pppoe_username'],'');
        $msg='✅ Pelanggan '.$cust['full_name'].' berhasil diaktifkan kembali!';
    }
}

if($act==='bayar'){
    $cid=(int)($_POST['cid']??0);
    $amount=(int)($_POST['amount']??0);
    $month=(int)($_POST['month']??date('n'));
    $year=(int)($_POST['year']??date('Y'));
    $notes=trim($_POST['notes']??'');
    if($cid&&$amount>0){
        $db->prepare("INSERT INTO pppoe_payments(customer_id,amount,payment_method,period_month,period_year,notes,created_by) VALUES(?,?,'cash',?,?,?,?)")
           ->execute([$cid,$amount,$month,$year,$notes,$_SESSION['admin_id']??null]);
        $db->prepare("UPDATE pppoe_customers SET last_paid_at=CURDATE(),last_paid_amount=? WHERE id=?")->execute([$amount,$cid]);
        $msg='✅ Pembayaran Rp '.number_format($amount,0,',','.').' berhasil dicatat!';
    }
}

if($act==='run_auto_isolir'){
    // Jalankan auto-isolir manual
    $grace=(int)($settings['isolir_grace_days']??3);
    $today=date('j');$todayDate=date('Y-m-d');
    $autoStmt=$db->prepare("SELECT pc.*,r.host,r.port r_port,r.username r_user,r.password r_pass FROM pppoe_customers pc JOIN routers r ON pc.router_id=r.id WHERE pc.status='active' AND pc.due_day<=? AND (pc.last_paid_at IS NULL OR pc.last_paid_at < DATE_FORMAT(CURDATE(), '%Y-%m-01')) AND r.is_active=1");
    $autoStmt->execute([(int)$today]);
    $candidates=$autoStmt->fetchAll();
    $isolated=0;
    foreach($candidates as $c){
        $dueDate=date('Y-m-').sprintf('%02d',$c['due_day']);
        $gracePassed=(strtotime($todayDate)-strtotime($dueDate))/86400>=$grace;
        if(!$gracePassed)continue;
        // Isolir
        $isoProfile=$settings['isolir_profile']??'isolir';
        $router=['host'=>$c['host'],'port'=>$c['r_port'],'username'=>$c['r_user'],'password'=>$c['r_pass']];
        $api=new MikrotikAPI($router['host'],(int)$router['port'],$router['username'],$router['password']);
        if($api->connect()){
            $api->talk(['/ppp/secret/set','?name='.$c['pppoe_username'],'=profile='.$isoProfile]);
            $acts=$api->parse($api->talk(['/ppp/active/print','?name='.$c['pppoe_username'],'=.proplist=.id']));
            foreach($acts as $a){if(isset($a['.id']))$api->talk(['/ppp/active/remove','=.id='.$a['.id']]);}
            $api->close();
        }
        $db->prepare("UPDATE pppoe_customers SET status='isolated',isolated_at=NOW(),isolated_reason='Auto-isolir: jatuh tempo' WHERE id=?")->execute([$c['id']]);
        auditLog('auto_isolir',$c['pppoe_username'],'Auto-isolir jatuh tempo tgl '.$c['due_day']);
        $isolated++;
    }
    $msg="✅ Auto-isolir selesai: $isolated pelanggan diisolir.";
}

// ── Load data ────────────────────────────────────────────
$tab=trim($_GET['tab']??'list');
$search=trim($_GET['q']??'');
$filterStatus=trim($_GET['status']??'');

$sql="SELECT pc.*,(SELECT COALESCE(SUM(amount),0) FROM pppoe_payments WHERE customer_id=pc.id AND period_year=YEAR(NOW()) AND period_month=MONTH(NOW()) AND midtrans_status!='pending') as paid_this_month FROM pppoe_customers pc WHERE pc.router_id=?";
$params=[$selRid];
if($search){$sql.=" AND (pc.pppoe_username LIKE ? OR pc.full_name LIKE ?)";$params[]="%$search%";$params[]="%$search%";}
if($filterStatus){$sql.=" AND pc.status=?";$params[]=$filterStatus;}
$sql.=" ORDER BY pc.status ASC,pc.full_name ASC";
$stmt=$db->prepare($sql);$stmt->execute($params);$customers=$stmt->fetchAll();

// Stats
try{
    $stats=$db->query("SELECT COUNT(*) total,SUM(status='active') active,SUM(status='isolated') isolated,SUM(monthly_price) total_monthly FROM pppoe_customers WHERE router_id=$selRid")->fetch();
}catch(\Exception $e){
    // Tabel belum ada - perlu jalankan database.sql
    die('<div style="font-family:sans-serif;padding:40px;max-width:600px;margin:50px auto;background:#FEF2F2;border:1px solid #FCA5A5;border-radius:8px"><h2 style="color:#DC2626">⚠️ Setup Diperlukan</h2><p>Tabel <code>pppoe_customers</code> belum ada di database.</p><p>Silakan jalankan file <strong>database.sql</strong> terlebih dahulu:</p><pre style="background:#1F2937;color:#F9FAFB;padding:12px;border-radius:6px">mysql -u USER -p DBNAME < database.sql</pre><p style="color:#6B7280;font-size:.85rem">Error: '.$e->getMessage().'</p></div>');
}

// Get MikroTik PPPoE active sessions
$activeSessions=[];
if($selRouter){
    try{
        $api=MikrotikAPI::fromRouter($selRouter);
        if($api->connect()){
            $activeSessions=array_column(
                $api->parse($api->talk(['/ppp/active/print','=.proplist=name,address,uptime,service'])),
                null,'name'
            );
            $api->close();
        }
    }catch(\Exception $e){}
}

// Today isolir candidates
$grace=(int)($settings['isolir_grace_days']??3);
$isolirCandidatesStmt=$db->prepare("SELECT COUNT(*) FROM pppoe_customers WHERE router_id=? AND status='active' AND due_day<=? AND (last_paid_at IS NULL OR last_paid_at < DATE_FORMAT(CURDATE(), '%Y-%m-01'))");
$isolirCandidatesStmt->execute([$selRid,(int)date('j')]);
$isolirCandidates=$isolirCandidatesStmt->fetchColumn();

startPage('PPPoE Manager');
?>
<style>
.pstats{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:18px}
.pstat{background:var(--white);border-radius:10px;padding:14px;border-left:4px solid var(--blue);box-shadow:var(--shadow-sm)}
.pstat.red{border-color:var(--red)}
.pstat.green{border-color:#16A34A}
.pstat.purple{border-color:#7C3AED}
.pstat-n{font-size:1.6rem;font-weight:900;color:var(--ink);line-height:1.1}
.pstat-l{font-size:.7rem;color:var(--g400);text-transform:uppercase;margin-top:2px}
.sts-active{background:#DCFCE7;color:#15803D;padding:2px 8px;border-radius:10px;font-size:.7rem;font-weight:700}
.sts-isolated{background:#FEE2E2;color:#DC2626;padding:2px 8px;border-radius:10px;font-size:.7rem;font-weight:700}
.sts-suspended{background:#FEF3C7;color:#D97706;padding:2px 8px;border-radius:10px;font-size:.7rem;font-weight:700}
.online-dot{width:7px;height:7px;border-radius:50%;background:#22C55E;display:inline-block;box-shadow:0 0 0 3px rgba(34,197,94,.2);animation:dp 2s infinite}
</style>

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:8px">
    <div>
        <h2 class="ph-t" style="margin:0">🏠 PPPoE Manager</h2>
        <div style="font-size:.78rem;color:var(--g400)">Kelola pelanggan PPPoE + Auto Isolir</div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <?php if($isolirCandidates>0):?>
        <form method="POST"><?=csrfField()?><input type="hidden" name="action" value="run_auto_isolir">
        <button class="btn" style="background:#DC2626;color:#fff" onclick="return confirm('Jalankan auto-isolir untuk <?=$isolirCandidates?> pelanggan jatuh tempo?')">
            ⚠️ <?=$isolirCandidates?> Jatuh Tempo — Isolir Sekarang
        </button></form>
        <?php endif;?>
        <button onclick="oM('moAddCustomer')" class="btn bp">➕ Tambah Pelanggan</button>
        <a href="?rid=<?=$selRid?>&tab=settings" class="btn bo">⚙️ Pengaturan</a>
    </div>
</div>

<?php if($msg):?>
<div class="alert a<?=$mtype?>" style="margin-bottom:14px"><?=$msg?></div>
<?php endif;?>

<!-- Router selector -->
<?php if(count($routers)>1):?>
<div class="card" style="padding:10px 14px;margin-bottom:14px">
    <div style="display:flex;align-items:center;gap:10px">
        <label style="font-size:.75rem;font-weight:700;color:var(--g600);white-space:nowrap">📡 ROUTER</label>
        <select onchange="location='?rid='+this.value+'&tab=<?=$tab?>'" class="fsel" style="max-width:280px">
            <?php foreach($routers as $r):?>
            <option value="<?=$r['id']?>" <?=$selRid==$r['id']?'selected':''?>><?=h($r['name'])?> — <?=h($r['ip_public'])?></option>
            <?php endforeach;?>
        </select>
    </div>
</div>
<?php endif;?>

<!-- Stats -->
<div class="pstats">
    <div class="pstat green"><div class="pstat-n"><?=$stats['active']??0?></div><div class="pstat-l">✅ Aktif</div></div>
    <div class="pstat red"><div class="pstat-n"><?=$stats['isolated']??0?></div><div class="pstat-l">🔴 Diisolir</div></div>
    <div class="pstat"><div class="pstat-n"><?=$stats['total']??0?></div><div class="pstat-l">👥 Total Pelanggan</div></div>
    <div class="pstat purple"><div class="pstat-n" style="font-size:1rem">Rp <?=number_format($stats['total_monthly']??0,0,',','.')?></div><div class="pstat-l">💰 Pendapatan/Bulan</div></div>
</div>

<?php if($tab==='settings'): // ── SETTINGS TAB ──────────
    $sk=[];foreach($db->query("SELECT setting_key,setting_value FROM pppoe_settings") as $s)$sk[$s['setting_key']]=$s['setting_value'];
?>
<div class="card">
    <div class="ch"><div class="ct">⚙️ Pengaturan PPPoE Manager & Midtrans</div></div>
    <div class="cb">
        <form method="POST">
            <?=csrfField()?>
            <input type="hidden" name="action" value="save_settings">
            <div class="f2">
                <div class="fg"><label class="fl">Midtrans Server Key</label><input type="text" name="midtrans_server_key" class="fc" value="<?=h($sk['midtrans_server_key']??'')?>" placeholder="SB-Mid-server-xxx"></div>
                <div class="fg"><label class="fl">Midtrans Client Key</label><input type="text" name="midtrans_client_key" class="fc" value="<?=h($sk['midtrans_client_key']??'')?>" placeholder="SB-Mid-client-xxx"></div>
            </div>
            <div class="f2">
                <div class="fg"><label class="fl">Mode Midtrans</label>
                    <select name="midtrans_mode" class="fsel">
                        <option value="sandbox" <?=($sk['midtrans_mode']??'sandbox')==='sandbox'?'selected':''?>>Sandbox (Testing)</option>
                        <option value="production" <?=($sk['midtrans_mode']??'')==='production'?'selected':''?>>Production</option>
                    </select>
                </div>
                <div class="fg"><label class="fl">Profile MikroTik Isolir</label><input type="text" name="isolir_profile" class="fc" value="<?=h($sk['isolir_profile']??'isolir')?>" placeholder="isolir"></div>
            </div>
            <div class="f2">
                <div class="fg"><label class="fl">Toleransi Hari Setelah Jatuh Tempo</label><input type="number" name="isolir_grace_days" class="fc" value="<?=h($sk['isolir_grace_days']??'3')?>" min="0" max="30"><div class="fhint">0 = isolir langsung di hari jatuh tempo</div></div>
                <div class="fg"><label class="fl">Nama Perusahaan</label><input type="text" name="company_name" class="fc" value="<?=h($sk['company_name']??'')?>"></div>
            </div>
            <div class="f2">
                <div class="fg"><label class="fl">No. Telepon/WA Perusahaan</label><input type="text" name="company_phone" class="fc" value="<?=h($sk['company_phone']??'')?>"></div>
                <div class="fg"><label class="fl">Alamat Perusahaan</label><input type="text" name="company_address" class="fc" value="<?=h($sk['company_address']??'')?>"></div>
            </div>
            <button type="submit" class="btn bp" style="width:100%;padding:10px">💾 Simpan Pengaturan</button>
        </form>
    </div>
</div>

<?php else: // ── LIST PELANGGAN TAB ──────────────────────?>

<!-- Search & filter -->
<div class="card" style="padding:10px 14px;margin-bottom:12px">
    <form method="GET" style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">
        <input type="hidden" name="rid" value="<?=$selRid?>">
        <div style="flex:1;min-width:180px"><input type="text" name="q" class="fc" placeholder="🔍 Cari username / nama..." value="<?=h($search)?>"></div>
        <select name="status" class="fsel" style="width:140px">
            <option value="">Semua Status</option>
            <option value="active" <?=$filterStatus==='active'?'selected':''?>>✅ Aktif</option>
            <option value="isolated" <?=$filterStatus==='isolated'?'selected':''?>>🔴 Diisolir</option>
        </select>
        <button type="submit" class="btn bo">Cari</button>
        <?php if($search||$filterStatus):?><a href="?rid=<?=$selRid?>" class="btn">✕ Reset</a><?php endif;?>
    </form>
</div>

<div class="card">
    <div class="ch">
        <div class="ct">👥 Pelanggan PPPoE (<?=count($customers)?>)</div>
        <div style="font-size:.7rem;color:var(--g400)"><?=count($activeSessions)?> sesi online</div>
    </div>
    <div class="tw">
    <table class="dt">
        <thead><tr>
            <th>Status</th><th>Username PPPoE</th><th>Nama</th><th>Profil</th>
            <th>Jatuh Tempo</th><th>Harga/Bln</th><th>Sesi Online</th><th>Aksi</th>
        </tr></thead>
        <tbody>
        <?php foreach($customers as $c):
            $online=isset($activeSessions[$c['pppoe_username']]);
            $today=date('j');
            $isLate=$c['status']==='active'&&$c['due_day']<=$today&&!$c['paid_this_month'];
            $daysLeft=$c['due_day']-(int)$today;
        ?>
        <tr style="<?=$c['status']==='isolated'?'background:#FFF5F5':''; ?>">
            <td>
                <?php if($c['status']==='active'&&$online):?>
                    <span class="sts-active">🟢 Online</span>
                <?php elseif($c['status']==='active'&&$isLate):?>
                    <span class="sts-suspended">⚠️ Jatuh Tempo</span>
                <?php elseif($c['status']==='active'):?>
                    <span class="sts-active">✅ Aktif</span>
                <?php else:?>
                    <span class="sts-isolated">🔴 Isolir</span>
                <?php endif;?>
            </td>
            <td><strong style="font-family:'JetBrains Mono',monospace;color:var(--blue-d)"><?=h($c['pppoe_username'])?></strong></td>
            <td><?=h($c['full_name'])?><?php if($c['phone']):?><br><span style="font-size:.7rem;color:var(--g400)"><?=h($c['phone'])?></span><?php endif;?></td>
            <td><span class="bdg" style="font-size:.7rem"><?=h($c['profile'])?:'-'?></span></td>
            <td>
                <strong>Tgl <?=$c['due_day']?></strong>
                <?php if($daysLeft>0&&$daysLeft<=5&&$c['status']==='active'):?>
                    <br><span style="font-size:.65rem;color:#D97706">⚡ <?=$daysLeft?> hari lagi</span>
                <?php elseif($isLate):?>
                    <br><span style="font-size:.65rem;color:var(--red)">⚠️ Terlambat!</span>
                <?php endif;?>
            </td>
            <td>Rp <?=number_format($c['monthly_price'],0,',','.')?></td>
            <td>
                <?php if($online):?>
                <span class="online-dot"></span>
                <span style="font-size:.7rem;margin-left:4px"><?=$activeSessions[$c['pppoe_username']]['address']??''?></span>
                <br><span style="font-size:.65rem;color:#16A34A"><?=$activeSessions[$c['pppoe_username']]['uptime']??''?></span>
                <?php else:?>
                <span style="color:var(--g400);font-size:.75rem">Offline</span>
                <?php endif;?>
            </td>
            <td>
                <div style="display:flex;gap:4px;flex-wrap:wrap">
                    <button onclick="openDetail(<?=$c['id']?>)" class="btn bo bxs" title="Detail">👤</button>
                    <button onclick="openBayar(<?=$c['id']?>,'<?=h($c['full_name'])?>',<?=$c['monthly_price']?>)" class="btn bxs" style="background:#16A34A;color:#fff" title="Catat Bayar">💰</button>
                    <?php if($c['status']==='active'):?>
                    <form method="POST" style="display:inline" onsubmit="return confirm('Isolir <?=h($c['pppoe_username'])?>?')">
                        <input type="hidden" name="action" value="isolir">
                        <input type="hidden" name="cid" value="<?=$c['id']?>">
                        <input type="hidden" name="reason" value="Manual oleh admin">
                        <button class="btn bxs" style="background:#DC2626;color:#fff" title="Isolir">🔴</button>
                    </form>
                    <?php else:?>
                    <form method="POST" style="display:inline" onsubmit="return confirm('Aktifkan kembali <?=h($c['pppoe_username'])?>?')">
                        <input type="hidden" name="action" value="reaktivasi">
                        <input type="hidden" name="cid" value="<?=$c['id']?>">
                        <button class="btn bxs" style="background:#16A34A;color:#fff" title="Aktifkan">✅</button>
                    </form>
                    <?php endif;?>
                </div>
            </td>
        </tr>
        <?php endforeach;?>
        <?php if(empty($customers)):?>
        <tr><td colspan="8" style="text-align:center;padding:30px;color:var(--g400)">Belum ada pelanggan PPPoE. <button onclick="oM('moAddCustomer')" class="btn bp bsm">➕ Tambah</button></td></tr>
        <?php endif;?>
        </tbody>
    </table>
    </div>
</div>
<?php endif;?>

<!-- Modal Tambah Pelanggan -->
<div class="mo" id="moAddCustomer">
    <div class="md" style="max-width:520px">
        <div class="mh"><div class="mt">➕ Tambah Pelanggan PPPoE</div><button class="mx" onclick="cM('moAddCustomer')">✕</button></div>
        <div class="mb">
            <form method="POST">
                <?=csrfField()?>
                <input type="hidden" name="action" value="add_customer">
                <div class="f2">
                    <div class="fg"><label class="fl">Username PPPoE *</label><input type="text" name="pppoe_username" class="fc" required placeholder="pelanggan01"></div>
                    <div class="fg"><label class="fl">Password MikroTik</label><input type="text" name="password" class="fc" placeholder="Kosong = tidak ubah MikroTik"><div class="fhint">Isi untuk tambah ke MikroTik sekaligus</div></div>
                </div>
                <div class="fg"><label class="fl">Nama Lengkap *</label><input type="text" name="full_name" class="fc" required placeholder="Budi Santoso"></div>
                <div class="f2">
                    <div class="fg"><label class="fl">No. HP/WA</label><input type="text" name="phone" class="fc" placeholder="08xxxxxxxxxx"></div>
                    <div class="fg"><label class="fl">Profil PPPoE</label><input type="text" name="profile" class="fc" placeholder="default"></div>
                </div>
                <div class="f2">
                    <div class="fg"><label class="fl">Harga/Bulan (Rp)</label><input type="number" name="monthly_price" class="fc" value="0" min="0"></div>
                    <div class="fg"><label class="fl">Tanggal Jatuh Tempo</label><input type="number" name="due_day" class="fc" value="<?=date('j')?>" min="1" max="28"><div class="fhint">Tanggal tagihan per bulan (1-28)</div></div>
                </div>
                <div class="fg"><label class="fl">Alamat</label><textarea name="address" class="fc" rows="2"></textarea></div>
                <button type="submit" class="btn bp" style="width:100%;padding:10px">➕ Tambah Pelanggan</button>
            </form>
        </div>
    </div>
</div>

<!-- Modal Catat Bayar -->
<div class="mo" id="moBayar">
    <div class="md" style="max-width:380px">
        <div class="mh"><div class="mt" id="bayarTitle">💰 Catat Pembayaran</div><button class="mx" onclick="cM('moBayar')">✕</button></div>
        <div class="mb">
            <form method="POST">
                <?=csrfField()?>
                <input type="hidden" name="action" value="bayar">
                <input type="hidden" name="cid" id="bayarCid">
                <div class="fg"><label class="fl">Jumlah Bayar (Rp)</label><input type="number" name="amount" id="bayarAmount" class="fc" min="0"></div>
                <div class="f2">
                    <div class="fg"><label class="fl">Bulan</label>
                        <select name="month" class="fsel">
                            <?php for($m=1;$m<=12;$m++):?>
                            <option value="<?=$m?>" <?=$m==date('n')?'selected':''?>><?=date('F',mktime(0,0,0,$m,1))?></option>
                            <?php endfor;?>
                        </select>
                    </div>
                    <div class="fg"><label class="fl">Tahun</label><input type="number" name="year" class="fc" value="<?=date('Y')?>" min="2020"></div>
                </div>
                <div class="fg"><label class="fl">Catatan</label><input type="text" name="notes" class="fc" placeholder="Bayar tunai..."></div>
                <button type="submit" class="btn bp" style="width:100%;padding:10px">💾 Simpan Pembayaran</button>
            </form>
        </div>
    </div>
</div>

<script>
function openBayar(cid,name,price){
    document.getElementById('bayarCid').value=cid;
    document.getElementById('bayarAmount').value=price;
    document.getElementById('bayarTitle').textContent='💰 Bayar — '+name;
    oM('moBayar');
}
function openDetail(cid){
    window.location='/admin/pppoe_detail.php?cid='+cid+'&rid=<?=$selRid?>';
}
</script>

<?php endPage();?>
