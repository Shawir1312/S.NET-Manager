<?php
define('IN_APP',true);
require_once __DIR__.'/../includes/config.php';
require_once __DIR__.'/../includes/layout.php';
requireAdmin();
$db=db();$msg='';$mtype='ok';

// Ensure genie_config exists
try{$db->query("SELECT 1 FROM genie_config LIMIT 1");}catch(Exception $e){
    $db->exec("CREATE TABLE IF NOT EXISTS genie_config(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) DEFAULT 'GenieACS',url VARCHAR(255) DEFAULT 'http://localhost:7557',username VARCHAR(100) DEFAULT '',password VARCHAR(255) DEFAULT '',is_active TINYINT(1) DEFAULT 1,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)");
    $db->exec("INSERT IGNORE INTO genie_config(id,name,url)VALUES(1,'GenieACS Lokal','http://localhost:7557')");
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    $act=$_POST['action']??'';
    if($act==='save'){
        $url=rtrim(trim($_POST['url']??''),'/');$name=trim($_POST['name']??'');$un=trim($_POST['username']??'');$pw=$_POST['password']??'';
        $db->prepare("UPDATE genie_config SET name=?,url=?,username=?,password=?,updated_at=NOW() WHERE id=1")->execute([$name,$url,$un,$pw]);
        $msg='✅ Konfigurasi GenieACS disimpan!';$mtype='ok';
    }
    if($act==='test'){
        $c=$db->query("SELECT * FROM genie_config WHERE id=1")->fetch();
        if($c){$g=new GenieACS($c['url'],$c['username'],$c['password']);$d=$g->getDevices('{}','_id');
            if(is_array($d)){$msg='✅ Koneksi berhasil! Ditemukan <strong>'.count($d).'</strong> perangkat ONT.';$mtype='ok';}
            else{$msg='❌ Gagal konek GenieACS: '.$g->error;$mtype='err';}
        }else{$msg='❌ Konfigurasi belum tersimpan.';$mtype='err';}
    }
}

$conf=$db->query("SELECT * FROM genie_config WHERE id=1")->fetch();
startPage('Config GenieACS');
?>
<div class="ph">
    <div><div class="ph-t">⚙️ Konfigurasi GenieACS</div><div class="ph-s">Integrasi GenieACS NBI untuk manajemen ONT via TR-069</div></div>
    <a href="/admin/ont.php" class="btn bp">📶 Monitor ONT</a>
</div>
<?php if($msg):?><div class="alert a<?=$mtype?>"><?=$msg?></div><?php endif;?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;align-items:start">
<div class="card" style="margin:0">
    <div class="ch"><div class="ct">🔗 Koneksi NBI GenieACS</div></div>
    <div class="cb">
        <form method="POST"><?=csrfField()?><input type="hidden" name="action" value="save">
            <div class="fg"><label class="fl">Nama Server</label><input type="text" name="name" class="fc" value="<?=h($conf['name']??'GenieACS')?>"></div>
            <div class="fg"><label class="fl">URL NBI *</label>
                <input type="text" name="url" class="fc" required value="<?=h($conf['url']??'http://localhost:7557')?>" placeholder="http://192.168.1.10:7557">
                <div class="fhint">Port NBI default GenieACS: <span class="code">7557</span></div>
            </div>
            <div class="frow2">
                <div class="fg"><label class="fl">Username <span style="font-weight:400;color:var(--g400)">(opsional)</span></label><input type="text" name="username" class="fc" value="<?=h($conf['username']??'')?>"></div>
                <div class="fg"><label class="fl">Password</label><input type="password" name="password" class="fc" placeholder="••••••"></div>
            </div>
            <div style="display:flex;gap:10px">
                <button type="submit" class="btn bp">💾 Simpan</button>
                <button type="button" class="btn bo" onclick="testConn()">🔌 Test Koneksi</button>
            </div>
        </form>
        <form method="POST" id="testForm" style="display:none"><?=csrfField()?><input type="hidden" name="action" value="test"></form>
    </div>
</div>

<div style="display:grid;gap:14px">
<div class="card" style="margin:0">
    <div class="ch"><div class="ct">📡 ONT yang Didukung</div></div>
    <div class="cb" style="font-size:.83rem;color:var(--g600);line-height:1.9">
        <?php foreach([
            ['🟠','FiberHome HG6145D2','WLANConfiguration.1/.5, PreSharedKey.1.KeyPassphrase'],
            ['🟠','FiberHome H3-2S XPON','WLANConfiguration.1/.5, PreSharedKey.1.KeyPassphrase'],
            ['🔵','C-Data FD511GD','WLANConfiguration.1/.5, KeyPassphrase (direct)'],
        ] as [$ic,$n,$p]):?>
        <div style="padding:8px 12px;border-radius:8px;background:var(--g50);border:1px solid var(--g200);margin-bottom:8px">
            <div style="font-weight:700;color:var(--g900)"><?=$ic?> <?=$n?></div>
            <div style="font-size:.72rem;font-family:'JetBrains Mono',monospace;color:var(--g500)"><?=$p?></div>
        </div>
        <?php endforeach;?>
    </div>
</div>

<div class="card" style="margin:0">
    <div class="ch"><div class="ct">⚙️ Setup ACS di ONT</div></div>
    <div class="cb" style="font-size:.83rem;line-height:1.8">
        <div style="display:grid;gap:6px">
            <div><span class="code">ACS URL</span> → <span style="color:var(--blue-d);font-weight:600">http://SERVER_IP:7547</span></div>
            <div><span class="code">Periodic Inform</span> → <span style="color:var(--blue-d);font-weight:600">Enable</span></div>
            <div><span class="code">Inform Interval</span> → <span style="color:var(--blue-d);font-weight:600">300 detik</span></div>
            <div><span class="code">Connection Req Auth</span> → <span style="color:var(--blue-d);font-weight:600">Enable</span></div>
        </div>
        <div class="alert ainf" style="margin-top:12px;margin-bottom:0">
            Port: <span class="code">7547</span> = NBI Device Interface | <span class="code">7557</span> = API Management
        </div>
    </div>
</div>
</div>
</div>

<script>function testConn(){document.getElementById('testForm').submit();}</script>
<?php endPage();?>
