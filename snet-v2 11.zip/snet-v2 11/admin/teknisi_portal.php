<?php
define('IN_APP',true);
require_once __DIR__.'/../includes/config.php';
require_once __DIR__.'/../includes/layout.php';
requireAdmin(); // Teknisi masuk sini, requireAdmin() sudah handle redirect ke halaman ini

$db=db();$msg='';$mtype='ok';
$genie=GenieACS::fromDB();

// ── Aksi: Ganti WiFi via ACS ──
if($_SERVER['REQUEST_METHOD']==='POST'){
    csrfVerify();
    $act=$_POST['action']??'';

    if($act==='set_wifi'){
        $devId=trim($_POST['genie_device_id']??'');
        $custId=(int)($_POST['customer_id']??0);
        $s24=trim($_POST['ssid_24']??'');$k24=trim($_POST['pass_24']??'');
        $s5g=trim($_POST['ssid_5g']??'');$k5g=trim($_POST['pass_5g']??'');
        if(!$devId){$msg='Device ACS tidak ditemukan untuk pelanggan ini.';$mtype='err';}
        elseif(!$genie){$msg='GenieACS tidak terhubung!';$mtype='err';}
        else{
            $dev=$genie->getDevice($devId);
            if(!$dev){$msg='Perangkat tidak ditemukan di ACS!';$mtype='err';}
            else{
                $ok=$genie->setWifi($devId,$dev,
                    ($s24!==''?$s24:null),($k24!==''?$k24:null),
                    ($s5g!==''?$s5g:null),($k5g!==''?$k5g:null));
                $msg=$ok?'✅ WiFi berhasil diubah! Perangkat ONT akan restart sebentar.':'❌ Gagal ubah WiFi: '.$genie->error;
                $mtype=$ok?'ok':'err';
                auditLog('teknisi_set_wifi',"cust:$custId device:$devId");
            }
        }
    }
    if($act==='edit_name'){
        $id=(int)($_POST['customer_id']??0);
        $name=trim($_POST['full_name']??'');$phone=trim($_POST['phone']??'');
        if(!$name){$msg='Nama tidak boleh kosong!';$mtype='err';}
        else{
            $db->prepare("UPDATE customers SET full_name=?,phone=?,updated_at=NOW() WHERE id=?")->execute([$name,$phone,$id]);
            auditLog('teknisi_edit_name',"cust:$id → $name");
            $msg='✅ Data pelanggan berhasil diupdate!';$mtype='ok';
        }
    }
}

// ── Daftar pelanggan ──
$q=trim($_GET['q']??'');
$wh=['1=1'];$pr=[];
if($q){$wh[]='(c.full_name LIKE ? OR c.customer_id LIKE ? OR c.phone LIKE ? OR c.device_serial LIKE ?)';$s="%$q%";$pr=[$s,$s,$s,$s];}
$custs=$db->prepare("SELECT c.*,r.name rn FROM customers c LEFT JOIN routers r ON c.router_id=r.id WHERE ".implode(' AND ',$wh)." ORDER BY c.full_name ASC");
$custs->execute($pr);$custs=$custs->fetchAll();

startPage('Portal Teknisi');
?>
<div class="ph">
    <div>
        <div class="ph-t">🔧 Portal Teknisi</div>
        <div class="ph-s">Lihat data pelanggan & konfigurasi WiFi ONT</div>
    </div>
</div>
<?php if($msg):?><div class="alert a<?=$mtype?>"><?=$msg?></div><?php endif;?>

<!-- Search -->
<div class="card"><div class="cb" style="padding:12px 16px">
<form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <div style="flex:1;min-width:200px"><label class="fl">🔍 Cari Pelanggan</label>
    <input type="text" name="q" class="fc" placeholder="Nama, ID, No. HP, Serial..." value="<?=h($q)?>" autofocus></div>
    <button type="submit" class="btn bp">Cari</button>
    <a href="/admin/teknisi_portal.php" class="btn bo">Reset</a>
</form>
</div></div>

<!-- Daftar pelanggan -->
<div class="card"><div class="ch"><div class="ct">👥 Daftar Pelanggan (<?=count($custs)?>)</div></div>
<div class="tw"><table class="dt"><thead><tr>
    <th>#</th><th>ID</th><th>Nama</th><th>No. HP</th><th>Brand ONT</th><th>Serial</th><th>Router</th><th>Status</th><th>Aksi</th>
</tr></thead><tbody>
<?php if(empty($custs)):?><tr><td colspan="9" class="empty">Belum ada pelanggan</td></tr><?php endif;?>
<?php foreach($custs as $i=>$c):?>
<tr>
    <td style="color:var(--g400);font-size:.76rem"><?=$i+1?></td>
    <td><span class="code"><?=h($c['customer_id'])?></span></td>
    <td>
        <div style="font-weight:700;font-size:.85rem"><?=h($c['full_name'])?></div>
        <?php if($c['address']):?><div style="font-size:.7rem;color:var(--g400)"><?=h(mb_substr($c['address'],0,40))?><?=mb_strlen($c['address'])>40?'…':''?></div><?php endif;?>
    </td>
    <td style="font-size:.8rem"><?=h($c['phone']?:'-')?></td>
    <td><span class="bdg borg" style="font-size:.63rem"><?=h($c['device_brand'])?></span></td>
    <td><span class="code" style="font-size:.68rem"><?=h($c['device_serial']?:'-')?></span></td>
    <td style="font-size:.76rem"><?=h($c['rn']?:'-')?></td>
    <td><span class="bdg <?=$c['is_active']?'bon':'boff'?>"><?=$c['is_active']?'Aktif':'Non'?></span></td>
    <td><div style="display:flex;gap:4px;flex-wrap:wrap">
        <button class="btn bp bsm" onclick='openWifi(<?=json_encode($c)?>)'>📶 WiFi</button>
        <button class="btn bo bsm" onclick='openEdit(<?=json_encode($c)?>)'>✏️ Nama</button>
    </div></td>
</tr>
<?php endforeach;?>
</tbody></table></div></div>

<!-- MODAL WiFi -->
<div class="mo" id="mWifi"><div class="md md-lg">
<div class="mh"><div class="mt">📶 Ubah WiFi Pelanggan</div><button class="mx" onclick="cM('mWifi')">✕</button></div>
<form method="POST"><div class="mb">
<?=csrfField()?><input type="hidden" name="action" value="set_wifi">
<input type="hidden" name="customer_id" id="wCustId">
<input type="hidden" name="genie_device_id" id="wDevId">

<div id="wInfo" style="background:#EFF6FF;border-radius:9px;padding:12px;margin-bottom:14px;border:1px solid #BFDBFE;font-size:.82rem">
    <div style="font-weight:700;color:var(--blue-d);margin-bottom:6px">📡 Info Perangkat</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px" id="wInfoGrid"></div>
</div>

<?php if(!$genie):?>
<div class="alert awrn">⚠️ GenieACS tidak terhubung. Hubungi administrator.</div>
<?php else:?>
<div style="background:var(--g50);border-radius:9px;padding:14px;margin-bottom:12px;border:1px solid var(--g200)">
    <div style="font-weight:700;color:var(--blue-d);margin-bottom:12px;font-size:.82rem">📡 WiFi 2.4 GHz</div>
    <div class="frow2">
        <div class="fg"><label class="fl">SSID (Nama WiFi)</label><input type="text" name="ssid_24" id="wS24" class="fc" placeholder="Kosong = tidak diubah"></div>
        <div class="fg"><label class="fl">Password</label><input type="text" name="pass_24" id="wK24" class="fc" placeholder="Min 8 karakter"></div>
    </div>
</div>
<div style="background:var(--g50);border-radius:9px;padding:14px;margin-bottom:12px;border:1px solid var(--g200)">
    <div style="font-weight:700;color:var(--purple);margin-bottom:12px;font-size:.82rem">📡 WiFi 5 GHz</div>
    <div class="frow2">
        <div class="fg"><label class="fl">SSID (Nama WiFi)</label><input type="text" name="ssid_5g" id="wS5g" class="fc" placeholder="Kosong = tidak diubah"></div>
        <div class="fg"><label class="fl">Password</label><input type="text" name="pass_5g" id="wK5g" class="fc" placeholder="Min 8 karakter"></div>
    </div>
</div>
<div class="alert ainf" style="margin:0">ℹ️ Kosongkan field yang tidak ingin diubah. ONT akan restart setelah perubahan dikirim.</div>
<?php endif;?>
</div>
<div class="mf">
    <button type="button" class="btn bo" onclick="cM('mWifi')">Batal</button>
    <?php if($genie):?><button type="submit" class="btn bp" onclick="return confirm('Kirim perubahan WiFi ke ONT?')">🚀 Kirim ke ONT</button><?php endif;?>
</div>
</form></div></div>

<!-- MODAL Edit Nama -->
<div class="mo" id="mEdit"><div class="md">
<div class="mh"><div class="mt">✏️ Edit Data Pelanggan</div><button class="mx" onclick="cM('mEdit')">✕</button></div>
<form method="POST"><div class="mb">
<?=csrfField()?><input type="hidden" name="action" value="edit_name">
<input type="hidden" name="customer_id" id="eCustId">
<div class="fg"><label class="fl">Nama Lengkap *</label><input type="text" name="full_name" id="eName" class="fc" required></div>
<div class="fg"><label class="fl">No. HP</label><input type="text" name="phone" id="ePhone" class="fc"></div>
<div class="alert ainf" style="margin:0">ℹ️ Teknisi hanya dapat mengubah nama dan nomor HP pelanggan.</div>
</div>
<div class="mf">
    <button type="button" class="btn bo" onclick="cM('mEdit')">Batal</button>
    <button type="submit" class="btn bp">💾 Simpan</button>
</div>
</form></div></div>

<script>
function openWifi(c){
    document.getElementById('wCustId').value=c.id;
    document.getElementById('wDevId').value=c.genie_device_id||'';
    document.getElementById('wS24').value='';document.getElementById('wK24').value='';
    document.getElementById('wS5g').value='';document.getElementById('wK5g').value='';
    const grid=document.getElementById('wInfoGrid');
    grid.innerHTML=`
        <div><b>Nama:</b> ${esc(c.full_name)}</div>
        <div><b>ID:</b> ${esc(c.customer_id)}</div>
        <div><b>Brand ONT:</b> ${esc(c.device_brand)}</div>
        <div><b>Model:</b> ${esc(c.device_model||'-')}</div>
        <div><b>Serial:</b> ${esc(c.device_serial||'-')}</div>
        <div><b>ACS ID:</b> <span style="font-size:.72rem;color:var(--blue-d)">${esc(c.genie_device_id||'Belum terhubung')}</span></div>`;
    oM('mWifi');
}
function openEdit(c){
    document.getElementById('eCustId').value=c.id;
    document.getElementById('eName').value=c.full_name;
    document.getElementById('ePhone').value=c.phone||'';
    oM('mEdit');
}
function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
</script>
<?php endPage();?>
