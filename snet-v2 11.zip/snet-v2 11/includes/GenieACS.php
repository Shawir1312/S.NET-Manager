<?php
if (!defined('IN_APP')) die('Direct access denied');
class GenieACS {
    private string $base, $user, $pass;
    public string $error = '';

    // TR-069 Root paths
    const IGD     = 'InternetGatewayDevice';
    const LAN_ETH = 'InternetGatewayDevice.LANDevice.1.LANEthernetInterfaceConfig';
    const WLAN    = 'InternetGatewayDevice.LANDevice.1.WLANConfiguration';
    const WAN_IP  = 'InternetGatewayDevice.WANDevice.1.WANConnectionDevice';
    const WAN_PPP = 'InternetGatewayDevice.WANDevice.1.WANConnectionDevice';

    // Brand detection: oui=prefix OUI, pid=product class substring
    // lan_bind = parameter name untuk binding LAN di WAN connection
    // vlan_id  = parameter untuk VLAN ID
    // vlan_en  = parameter untuk enable VLAN (jika ada)
    // svclist  = parameter service list
    // wifi_key = path WiFi password (PreSharedKey.1.KeyPassphrase vs KeyPassphrase)
    const BRANDS = [
        'FiberHome' => [
            'oui'      => ['000B82','ACDF00','48573A'],
            'pid'      => ['hg6145','h3-2s','h32s','xpon','fiberhome'],
            'mfr'      => ['FiberHome'],
            'lan_bind' => 'X_FH_LanInterface',
            'vlan_id'  => 'VLANID',
            'vlan_en'  => 'VLANEnable',
            'svclist'  => 'X_FH_ServiceList',
            'wifi_key' => 'PreSharedKey.1.KeyPassphrase',
            'wifi_key2'=> 'PreSharedKey.1.PreSharedKey',
        ],
        'ZTE' => [
            'oui'      => ['C8700A','A88090','ZCOMI0','C078BE'],
            'pid'      => ['f670','f660','f609','f6600','zte','zxhn'],
            'mfr'      => ['ZTE','ZXHN'],
            'rx_path'  => 'InternetGatewayDevice.WANDevice.1.X_ZTE-COM_WANPONInterfaceConfig.RXPower',
            'lan_bind' => 'X_ZTE-COM_LanInterface',
            'vlan_id'  => 'X_ZTE-COM_VLANID',
            'vlan_en'  => 'X_ZTE-COM_VLANEnable',
            'svclist'  => 'X_ZTE-COM_ServiceList',
            'wifi_key' => 'PreSharedKey.1.KeyPassphrase',
        ],
        'Huawei' => [
            'oui'      => ['E8CD2D','D05FB8','00E0FC','4CB16C'],
            'pid'      => ['hg','hs','huawei','echolife'],
            'mfr'      => ['Huawei Technologies Co., Ltd','Huawei'],
            'hw_detect'=> 'InternetGatewayDevice.DeviceInfo.X_HW_SerialNumber',
            'lan_bind' => 'X_HW_LANBIND',   // khusus: pakai enable per port
            'vlan_id'  => 'X_HW_VLAN',
            'vlan_en'  => null,
            'svclist'  => 'X_HW_SERVICELIST',
            'wifi_key' => 'PreSharedKey.1.KeyPassphrase',
        ],
        'CMCC' => [
            'oui'      => [],
            'pid'      => [],
            'mfr'      => [],
            'cmcc_detect' => 'InternetGatewayDevice.X_CMCC_UserInfo.ServiceName',
            'lan_bind' => 'X_CMCC_LanInterface',
            'vlan_id'  => 'X_CMCC_VLANIDMark',
            'vlan_en'  => 'X_CMCC_VLANMode',  // 2=enable, 1=disable
            'svclist'  => 'X_CMCC_ServiceList',
            'wifi_key' => 'PreSharedKey.1.KeyPassphrase',
        ],
        'CTCOM' => [
            'oui'      => [],
            'pid'      => [],
            'mfr'      => [],
            'ct_detect'=> 'InternetGatewayDevice.X_CT-COM_UserInfo.ServiceName',
            'lan_bind' => 'X_CT-COM_LanInterface',
            'vlan_id'  => 'X_CT-COM_VLANIDMark',
            'vlan_en'  => 'X_CT-COM_VLANMode',
            'svclist'  => 'X_CT-COM_ServiceList',
            'wifi_key' => 'PreSharedKey.1.KeyPassphrase',
        ],
        'CData' => [
            'oui'      => ['F04DA2','606B9C','A80720','84C230'],
            'pid'      => ['fd511','cdata','fd505'],
            'mfr'      => ['CData','C-Data'],
            'lan_bind' => 'X_CData_BindingLAN',
            'vlan_id'  => 'X_CData_VLANID',
            'vlan_en'  => null,
            'svclist'  => 'ServiceList',
            'wifi_key' => 'KeyPassphrase',
        ],
    ];

    // WiFi path per index SSID (index 1-4 = 2.4G, 5-8 = 5G untuk kebanyakan ONT)
    const WLAN_PATH = 'InternetGatewayDevice.LANDevice.1.WLANConfiguration';

    public function __construct(string $url, string $u='', string $p='') {
        $this->base=rtrim($url,'/'); $this->user=$u; $this->pass=$p;
    }

    private function req(string $method, string $path, $body=null) {
        if(!function_exists('curl_init')){$this->error='cURL not available';return null;}
        $ch=curl_init($this->base.$path);
        $opts=[CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>25,CURLOPT_CUSTOMREQUEST=>$method,
               CURLOPT_HTTPHEADER=>['Content-Type: application/json','Accept: application/json'],
               CURLOPT_SSL_VERIFYHOST=>(getenv('GENIE_SSL_VERIFY')==='true'?2:0),CURLOPT_SSL_VERIFYPEER=>(getenv('GENIE_SSL_VERIFY')==='true')];
        if($this->user) $opts[CURLOPT_USERPWD]="$this->user:$this->pass";
        if($body!==null){
            $opts[CURLOPT_POSTFIELDS]=is_string($body)?$body:json_encode($body,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        }
        curl_setopt_array($ch,$opts);
        $resp=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);
        curl_close($ch);
        if($err){$this->error=$err;return null;}
        if($code>=400){$this->error="HTTP $code: ".substr($resp??'',0,300);return null;}
        return $resp!==false?($resp?json_decode($resp,true)??true:true):null;
    }

    // Kirim task ke GenieACS NBI
    private function sendTask(string $devId, array $task): bool {
        $enc=rawurlencode($devId);
        $body=json_encode($task,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        // Coba dengan connection_request dulu (ONT online)
        $r=$this->req('POST',"/devices/{$enc}/tasks?timeout=3000&connection_request",$body);
        if($r===null){
            $this->error='';
            // Fallback: queue task (ONT offline/delayed)
            $r=$this->req('POST',"/devices/{$enc}/tasks",$body);
        }
        return $r!==null;
    }

    public function getDevices(string $q='{}',string $proj=''): array {
        $qs='?query='.urlencode($q);
        if($proj)$qs.='&projection='.urlencode($proj);
        return (array)($this->req('GET','/devices'.$qs)??[]);
    }
    public function getDevice(string $id): ?array {
        $r=$this->getDevices(json_encode(['_id'=>$id]));return $r[0]??null;
    }
    public function searchDevices(string $term): array {
        $s=addslashes($term);
        $q=json_encode(['$or'=>[
            ['_deviceId._SerialNumber'=>['$regex'=>$s,'$options'=>'i']],
            ['_tags'=>$s],
            [self::WLAN_PATH.'.1.SSID._value'=>['$regex'=>$s,'$options'=>'i']],
        ]]);
        return $this->getDevices($q);
    }

    // ── DETEKSI BRAND dari device data ──────────────────────────────
    public function detectBrand(array $dev): array {
        $oui=strtoupper(str_replace([':','-'],'',($dev['_deviceId']['_OUI']??'')));
        $pid=strtolower($dev['_deviceId']['_ProductClass']??'');
        $mfr=$dev['_deviceId']['_Manufacturer']??'';
        $id=strtolower($dev['_id']??'');

        // Cek field khusus di data device (dari summon)
        $hasHW=($this->dig($dev,'InternetGatewayDevice.DeviceInfo.X_HW_SerialNumber')!==null);
        $hasCMCC=($this->dig($dev,'InternetGatewayDevice.X_CMCC_UserInfo.ServiceName')!==null);
        $hasCT=($this->dig($dev,'InternetGatewayDevice.X_CT-COM_UserInfo.ServiceName')!==null)||
               ($this->dig($dev,'InternetGatewayDevice.X_CT-COM_UserInfo.UserName')!==null);
        $hasCU=($this->dig($dev,'InternetGatewayDevice.X_CU_UserInfo.UserName')!==null);
        $hasZTE=($this->dig($dev,'InternetGatewayDevice.WANDevice.1.X_ZTE-COM_WANPONInterfaceConfig.RXPower')!==null);

        if($hasZTE||str_contains(strtolower($mfr),'zte')) return self::BRANDS['ZTE'];
        if($hasHW||str_contains(strtolower($mfr),'huawei')) return self::BRANDS['Huawei'];
        if($hasCMCC) return self::BRANDS['CMCC'];
        if($hasCT) return self::BRANDS['CTCOM'];

        // OUI/PID match
        foreach(self::BRANDS as $b){
            if(!empty($b['oui'])){
                foreach($b['oui'] as $o){ if(str_starts_with($oui,strtoupper($o))) return $b; }
            }
            if(!empty($b['pid'])){
                foreach($b['pid'] as $k){ if(str_contains($pid,$k)||str_contains($id,$k)) return $b; }
            }
            if(!empty($b['mfr'])){
                foreach($b['mfr'] as $m){ if(str_contains(strtolower($mfr),strtolower($m))) return $b; }
            }
        }
        // Default FiberHome
        return self::BRANDS['FiberHome'];
    }

    // Legacy alias
    public function detectModel(array $dev): array {
        $b=$this->detectBrand($dev);
        $m=$dev['_deviceId']['_ProductClass']??'ONT';
        $mfr=$dev['_deviceId']['_Manufacturer']??'Unknown';
        $wk=$b['wifi_key']??'PreSharedKey.1.KeyPassphrase';
        return [
            'brand'=>$mfr,'model'=>$m,
            'ssid24'=>self::WLAN_PATH.'.1.SSID',
            'key24' =>self::WLAN_PATH.'.1.'.$wk,
            'ssid5g'=>self::WLAN_PATH.'.5.SSID',
            'key5g' =>self::WLAN_PATH.'.5.'.$wk,
            'sec24' =>self::WLAN_PATH.'.1.BeaconType',
            'sec5g' =>self::WLAN_PATH.'.5.BeaconType',
            'cli24' =>self::WLAN_PATH.'.1.AssociatedDevice',
            'cli5g' =>self::WLAN_PATH.'.5.AssociatedDevice',
        ];
    }

    public function dig(array $d, string $path): ?string {
        $cur=$d;
        foreach(explode('.',$path) as $k){
            if(!is_array($cur)||!array_key_exists($k,$cur))return null;
            $cur=$cur[$k];
        }
        return is_array($cur)?($cur['_value']??null):(is_string($cur)||is_numeric($cur)?(string)$cur:null);
    }

    public function getWifi(array $dev): array {
        $m=$this->detectModel($dev);
        $wk=$this->detectBrand($dev)['wifi_key']??'PreSharedKey.1.KeyPassphrase';
        // Coba PreSharedKey.1.KeyPassphrase dulu, fallback KeyPassphrase
        $k24=$this->dig($dev,self::WLAN_PATH.'.1.PreSharedKey.1.KeyPassphrase')
            ??$this->dig($dev,self::WLAN_PATH.'.1.KeyPassphrase')
            ??$this->dig($dev,self::WLAN_PATH.'.1.PreSharedKey.1.PreSharedKey');
        $k5g=$this->dig($dev,self::WLAN_PATH.'.5.PreSharedKey.1.KeyPassphrase')
            ??$this->dig($dev,self::WLAN_PATH.'.5.KeyPassphrase')
            ??$this->dig($dev,self::WLAN_PATH.'.5.PreSharedKey.1.PreSharedKey');
        return [
            'ssid_24'=>$this->dig($dev,self::WLAN_PATH.'.1.SSID'),
            'pass_24'=>$k24,
            'ssid_5g'=>$this->dig($dev,self::WLAN_PATH.'.5.SSID'),
            'pass_5g'=>$k5g,
            // legacy keys
            'ssid24'=>$this->dig($dev,self::WLAN_PATH.'.1.SSID'),
            'key24' =>$k24,
            'ssid5g'=>$this->dig($dev,self::WLAN_PATH.'.5.SSID'),
            'key5g' =>$k5g,
            'sec24' =>$this->dig($dev,self::WLAN_PATH.'.1.BeaconType'),
            'sec5g' =>$this->dig($dev,self::WLAN_PATH.'.5.BeaconType'),
            'model' =>$m,
        ];
    }

    public function getClients(array $dev): array {
        $out=[];
        foreach([1=>'2.4G',2=>'2.4G',5=>'5G',6=>'5G',7=>'5G',8=>'5G'] as $idx=>$band){
            $base=self::WLAN_PATH.".$idx.AssociatedDevice";
            $ena=$this->dig($dev,self::WLAN_PATH.".$idx.Enable");
            if($ena!==null&&$ena!=='true'&&$ena!=='1') continue;
            for($i=1;$i<=32;$i++){
                $mac=$this->dig($dev,"$base.$i.AssociatedDeviceMACAddress");
                if(!$mac) break;
                $ip=$this->dig($dev,"$base.$i.AssociatedDeviceIPAddress")
                   ??$this->dig($dev,"$base.$i.X_BROADCOM_COM_IPAddress")?:'-';
                $rssi=$this->dig($dev,"$base.$i.X_HW_RSSI")
                    ??$this->dig($dev,"$base.$i.AssociatedDeviceRssi")
                    ??$this->dig($dev,"$base.$i.X_BROADCOM_COM_RSSI")
                    ??$this->dig($dev,"$base.$i.SignalStrength")?:'-';
                $hn=$this->dig($dev,"$base.$i.X_HW_AssociatedDevicedescriptions")
                  ??$this->dig($dev,"$base.$i.X_ZTE-COM_AssociatedDeviceName")
                  ??$this->dig($dev,"$base.$i.X_BROADCOM_COM_Hostname")?:'-';
                $out[]=['mac'=>$mac,'band'=>$band,'ip'=>$ip,'rssi'=>$rssi,'hostname'=>$hn,'ssid_idx'=>$idx];
            }
        }
        return $out;
    }

    public function getWanList(array $dev): array {
        $out=[];
        $wanDevPath='InternetGatewayDevice.WANDevice.1.WANConnectionDevice';
        for($cd=1;$cd<=5;$cd++){
            foreach(['WANIPConnection'=>'ip','WANPPPConnection'=>'ppp'] as $connType=>$tkey){
                $base="$wanDevPath.$cd.$connType";
                $name=$this->dig($dev,"$base.1.Name")?:$this->dig($dev,"$base.1.ConnectionType");
                if($name!==null){
                    $out["$tkey.$cd"]=[
                        'slot'=>$cd,'type'=>$tkey,
                        'label'=>($tkey==='ppp'?'WAN PPP':'WAN IP')." Slot $cd",
                        'name'=>$name,
                        'conn_type'=>$this->dig($dev,"$base.1.ConnectionType")?:'',
                        'status'=>$this->dig($dev,"$base.1.ConnectionStatus")?:'-',
                        'ip'=>$this->dig($dev,"$base.1.ExternalIPAddress")?:'-',
                        'gw'=>$this->dig($dev,"$base.1.DefaultGateway")?:'-',
                        'nat'=>$this->dig($dev,"$base.1.NATEnabled")?:'-',
                        'vlan'=>$this->dig($dev,"$base.1.X_HW_VLAN")
                              ??$this->dig($dev,"$base.1.X_ZTE-COM_VLANID")
                              ??$this->dig($dev,"$base.1.VLANID")
                              ??$this->dig($dev,"$base.1.X_CMCC_VLANIDMark")
                              ??$this->dig($dev,"$base.1.X_CT-COM_VLANIDMark")?:'-',
                    ];
                }
            }
        }
        return $out;
    }

    public function getInfo(array $dev): array {
        $last=$dev['_lastInform']??null;
        $diff=$last?(time()-strtotime($last))/60:PHP_INT_MAX;
        $m=$this->detectModel($dev);
        $mfr=$dev['_deviceId']['_Manufacturer']??'-';
        return [
            'id'         =>$dev['_id']??'-',
            'serial'     =>$dev['_deviceId']['_SerialNumber']??'-',
            'oui'        =>$dev['_deviceId']['_OUI']??'-',
            'manufacturer'=>$mfr,
            'product'    =>$dev['_deviceId']['_ProductClass']??'-',
            'sw_version' =>$this->dig($dev,'InternetGatewayDevice.DeviceInfo.SoftwareVersion')?:'-',
            'hw_version' =>$this->dig($dev,'InternetGatewayDevice.DeviceInfo.HardwareVersion')?:'-',
            'uptime'     =>$this->dig($dev,'InternetGatewayDevice.DeviceInfo.UpTime')?:'-',
            'ip_wan'     =>$this->dig($dev,'InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANIPConnection.1.ExternalIPAddress')
                          ??$this->dig($dev,'InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1.ExternalIPAddress')?:'-',
            'last_inform'=>$last,
            'online'     =>$diff<10,
            'last_seen'  =>$diff<1?'Baru saja':($diff<60?round($diff).'m lalu':($last?date('d/m H:i',strtotime($last)):'-')),
            'tags'       =>$dev['_tags']??[],
            'brand'      =>$mfr,
            'model'      =>$m['model'],
        ];
    }

    // ── SET WIFI — kirim SSID + password, task terpisah per band ──
    // Pisah 2.4G dan 5G supaya jika salah satu gagal tidak menghambat yang lain
    // samePass=true: password 2.4G dikirim ke 5G juga
    public function setWifi(string $devId, array $dev, ?string $s24, ?string $k24, ?string $s5g, ?string $k5g, bool $samePass=false): bool {
        $brand  = $this->detectBrand($dev);
        $wk     = $brand['wifi_key']??'PreSharedKey.1.KeyPassphrase';
        $k5use  = $samePass ? $k24 : $k5g;
        $base   = self::WLAN_PATH;
        $anyOk  = false;

        // ── 2.4 GHz (index 1) ──
        $p24=[];
        if($s24!==null&&$s24!=='') $p24[]=[$base.'.1.SSID',$s24,'xsd:string'];
        if($k24!==null&&$k24!==''){
            $p24[]=[$base.'.1.'.$wk,$k24,'xsd:string'];
            $p24[]=[$base.'.1.BeaconType','11i','xsd:string'];
        }
        if(!empty($p24)){
            $r=$this->sendTask($devId,['name'=>'setParameterValues','parameterValues'=>$p24]);
            if($r) $anyOk=true; else $this->error='';
        }

        // ── 5 GHz (index 5) ──
        $p5g=[];
        if($s5g!==null&&$s5g!=='') $p5g[]=[$base.'.5.SSID',$s5g,'xsd:string'];
        if($k5use!==null&&$k5use!==''){
            $p5g[]=[$base.'.5.'.$wk,$k5use,'xsd:string'];
            $p5g[]=[$base.'.5.BeaconType','11i','xsd:string'];
        }
        if(!empty($p5g)){
            $r=$this->sendTask($devId,['name'=>'setParameterValues','parameterValues'=>$p5g]);
            if($r) $anyOk=true; else $this->error='';
        }

        if(!$anyOk&&empty($p24)&&empty($p5g)){
            $this->error='Tidak ada parameter WiFi yang diisi';return false;
        }
        if(!$anyOk) $this->error='Gagal mengirim parameter WiFi ke ONT';
        return $anyOk;
    }

    // ── SET WAN — kirim parameter MINIMAL sesuai brand ────────────
    // Error 9003 = parameter tidak dikenal/didukung ONT
    // Solusi: kirim HANYA parameter yang pasti ada, 1 task per kelompok parameter
    // connMode: route=IP_Routed | bridge_ip=IP_Bridged | bridge_ppp=PPPoE_Bridged
    public function setWan(string $devId, array $dev, array $cfg): bool {
        $brand    = $this->detectBrand($dev);
        $slot     = max(1,(int)($cfg['wan_slot']??1));
        $connMode = $cfg['conn_mode']??'route';
        $svcList  = $cfg['service_list']??'INTERNET';
        $vlanEn   = !empty($cfg['vlan_enable']) && !empty($cfg['vlan_id']);
        $vlanId   = (int)($cfg['vlan_id']??0);
        $wanName  = trim($cfg['wan_name']??'');
        $wanBase  = 'InternetGatewayDevice.WANDevice.1.WANConnectionDevice';

        // ── Tentukan base path dan connection type ──
        if($connMode==='bridge_ppp'){
            $base     = "$wanBase.$slot.WANPPPConnection.1";
            $connType = 'PPPoE_Bridged';
        } elseif($connMode==='bridge_ip'){
            $base     = "$wanBase.$slot.WANIPConnection.1";
            $connType = 'IP_Bridged';
        } else {
            $base     = "$wanBase.$slot.WANIPConnection.1";
            $connType = 'IP_Routed';
        }

        // ── Parameter INTI (selalu dikirim) ──
        // Hanya 3 parameter wajib: Enable, ConnectionType, ServiceList
        // Ini yang paling aman dan tidak akan error 9003
        $core = [
            [$base.'.Enable',         'true',     'xsd:boolean'],
            [$base.'.ConnectionType', $connType,  'xsd:string'],
        ];

        // Service list — coba brand-specific dulu, lalu generic
        $svcParam = $brand['svclist']??'ServiceList';
        $core[] = [$base.'.'.$svcParam, $svcList, 'xsd:string'];

        // Nama WAN (opsional)
        if($wanName) $core[] = [$base.'.Name', $wanName, 'xsd:string'];

        // NAT hanya untuk route mode
        if($connMode==='route'){
            $core[] = [$base.'.NATEnabled', 'true', 'xsd:boolean'];
        } elseif($connMode==='bridge_ip'){
            $core[] = [$base.'.NATEnabled', 'false', 'xsd:boolean'];
        }

        // ── Kirim core parameters dulu ──
        $ok = $this->sendTask($devId, [
            'name'=>'setParameterValues',
            'parameterValues'=>$core
        ]);
        if(!$ok) return false;

        // ── Parameter addressing (route mode) ──
        if($connMode==='route'){
            $addrParams = [];
            $addrType = $cfg['addr_type']??'dhcp';
            if($addrType==='static'){
                $addrParams[] = [$base.'.AddressingType','Static','xsd:string'];
                if(!empty($cfg['static_ip']))   $addrParams[]=[$base.'.ExternalIPAddress',$cfg['static_ip'],'xsd:string'];
                if(!empty($cfg['static_mask'])) $addrParams[]=[$base.'.SubnetMask',$cfg['static_mask'],'xsd:string'];
                if(!empty($cfg['static_gw']))   $addrParams[]=[$base.'.DefaultGateway',$cfg['static_gw'],'xsd:string'];
                if(!empty($cfg['dns1'])){
                    $dns=$cfg['dns1'].(!empty($cfg['dns2'])?','.$cfg['dns2']:'');
                    $addrParams[]=[$base.'.DNSServers',$dns,'xsd:string'];
                }
            } else {
                $addrParams[]=[$base.'.AddressingType','DHCP','xsd:string'];
            }
            if(!empty($cfg['pppoe_user'])) $addrParams[]=[$base.'.Username',$cfg['pppoe_user'],'xsd:string'];
            if(!empty($cfg['pppoe_pass'])) $addrParams[]=[$base.'.Password',$cfg['pppoe_pass'],'xsd:string'];
            if(!empty($addrParams)){
                $this->sendTask($devId,['name'=>'setParameterValues','parameterValues'=>$addrParams]);
                // Ignore error di sini — param addressing mungkin tidak ada di semua ONT
                $this->error='';
            }
        }

        // PPPoE bridge credentials
        if($connMode==='bridge_ppp' && (!empty($cfg['pppoe_user'])||!empty($cfg['pppoe_pass']))){
            $pppParams=[];
            if(!empty($cfg['pppoe_user'])) $pppParams[]=[$base.'.Username',$cfg['pppoe_user'],'xsd:string'];
            if(!empty($cfg['pppoe_pass'])) $pppParams[]=[$base.'.Password',$cfg['pppoe_pass'],'xsd:string'];
            $this->sendTask($devId,['name'=>'setParameterValues','parameterValues'=>$pppParams]);
            $this->error='';
        }

        // ── VLAN — kirim HANYA parameter brand ini (bukan semua brand) ──
        // Kirim dalam task terpisah agar jika gagal tidak mempengaruhi WAN utama
        if($vlanEn && $vlanId>0){
            $vlanParams=[];
            // Brand-specific VLAN parameter
            $vid = $brand['vlan_id']??null;
            $ven = $brand['vlan_en']??null;
            if($vid) $vlanParams[]=[$base.'.'.$vid,(string)$vlanId,'xsd:unsignedInt'];
            if($ven){
                $venVal = in_array($ven,['X_CMCC_VLANMode','X_CT-COM_VLANMode']) ? '2' : 'true';
                $venType= in_array($ven,['X_CMCC_VLANMode','X_CT-COM_VLANMode']) ? 'xsd:int' : 'xsd:boolean';
                $vlanParams[]=[$base.'.'.$ven,$venVal,$venType];
            }
            // Generic VLAN params yang ada di hampir semua ONT
            $vlanParams[]=[$base.'.VLANEnable','true','xsd:boolean'];
            $vlanParams[]=[$base.'.VLANID',(string)$vlanId,'xsd:unsignedInt'];

            if(!empty($vlanParams)){
                $vok=$this->sendTask($devId,['name'=>'setParameterValues','parameterValues'=>$vlanParams]);
                if(!$vok) $this->error=''; // Reset error - VLAN mungkin tidak didukung tapi WAN tetap sukses
            }
        }

        return true; // Core params berhasil dikirim
    }

    // ── BINDING WAN → LAN/WLAN ────────────────────────────────────
    // Kirim dalam task terpisah: 1 task untuk brand utama, tidak kirim semua brand sekaligus
    // Ini menghindari error 9003 dari parameter yang tidak dikenal ONT
    public function bindWan(string $devId, array $dev, array $cfg): bool {
        $brand    = $this->detectBrand($dev);
        $bindStr  = trim($cfg['bind_str']??'');
        if(!$bindStr){$this->error='Pilih minimal satu interface untuk di-bind';return false;}

        $slot     = max(1,(int)($cfg['wan_slot']??1));
        $wanType  = $cfg['wan_type']??'ip';
        $wanBase  = 'InternetGatewayDevice.WANDevice.1.WANConnectionDevice';
        $connType = ($wanType==='ppp')?'WANPPPConnection':'WANIPConnection';
        $base     = "$wanBase.$slot.$connType.1";
        $bindParam= $brand['lan_bind']??'X_FH_LanInterface';

        // ── Huawei: X_HW_LANBIND — set per port boolean ──
        if($bindParam==='X_HW_LANBIND'){
            $params=[];
            // Reset semua
            for($i=1;$i<=4;$i++)  $params[]=[$base.".X_HW_LANBIND.Lan{$i}Enable",'false','xsd:boolean'];
            for($i=1;$i<=8;$i++)  $params[]=[$base.".X_HW_LANBIND.SSID{$i}Enable",'false','xsd:boolean'];
            // Set yang dipilih ke true
            foreach(array_map('trim',explode(',',$bindStr)) as $p){
                if(preg_match('/LANEthernetInterfaceConfig\.(\d+)$/',$p,$m))
                    $params[]=[$base.".X_HW_LANBIND.Lan{$m[1]}Enable",'true','xsd:boolean'];
                if(preg_match('/WLANConfiguration\.(\d+)$/',$p,$m))
                    $params[]=[$base.".X_HW_LANBIND.SSID{$m[1]}Enable",'true','xsd:boolean'];
            }
            return $this->sendTask($devId,['name'=>'setParameterValues','parameterValues'=>$params]);
        }

        // ── Non-Huawei: kirim binding string ke parameter brand-specific ──
        // Kirim HANYA parameter brand yang terdeteksi, bukan semua brand
        $ok = $this->sendTask($devId,[
            'name'=>'setParameterValues',
            'parameterValues'=>[[$base.'.'.$bindParam, $bindStr, 'xsd:string']]
        ]);

        // Jika brand-specific gagal, coba generic fallback satu per satu
        if(!$ok){
            $this->error='';
            // Fallback: coba parameter umum lainnya
            $fallbacks=['X_FH_LanInterface','X_ZTE-COM_LanInterface','X_CMCC_LanInterface',
                        'X_CT-COM_LanInterface','X_CU_LanInterface'];
            foreach($fallbacks as $fb){
                if($fb===$bindParam) continue;
                $this->error='';
                $r=$this->sendTask($devId,['name'=>'setParameterValues',
                    'parameterValues'=>[[$base.'.'.$fb,$bindStr,'xsd:string']]]);
                if($r){$ok=true;break;}
            }
        }

        // ── ZTE F670L: binding via X_ZTE-COM_PortBinding table ──
        $wanInterface=trim($cfg['wan_interface']??'');
        if($wanInterface){
            $this->error='';
            $this->sendTask($devId,['name'=>'setParameterValues','parameterValues'=>[
                ['InternetGatewayDevice.X_ZTE-COM_PortBinding.1.WANInterface',$wanInterface,'xsd:string'],
                ['InternetGatewayDevice.X_ZTE-COM_PortBinding.1.LANInterface',$bindStr,'xsd:string'],
            ]]);
            $this->error=''; // Jangan error jika ZTE-COM_PortBinding tidak ada
        }

        if(!$ok) $this->error="Binding gagal: parameter tidak didukung ONT ini. Coba ubah WAN Slot atau Tipe WAN.";
        return $ok;
    }

    // ── BLOKIR CLIENT — MAC address filter ────────────────────────
    // Dari dokumen GenieACS YAML tidak ada blokir langsung, tapi bisa via
    // WLANConfiguration.N.AccessControl / MACAddressControlList
    public function blockClient(string $devId, array $dev, string $mac): bool {
        // Detect brand dari raw device data (GenieACS format)
        if(isset($dev['brand'])){$brand=$dev['brand'];}
        elseif(isset($dev['_deviceId'])){$b=$this->detectBrand($dev);$brand=$b['name']??'FiberHome';}
        else{$brand='FiberHome';}
        $mac=strtoupper(trim($mac));

        // ── FiberHome: InternetGatewayDevice.X_FH_Firewall.MACFilter ──
        if($brand==='FiberHome'){
            // Step 1: Aktifkan MAC Filter mode black
            $init=[
                ['InternetGatewayDevice.X_FH_Firewall.MACFEnable','true','xsd:boolean'],
            ];
            $this->sendTask($devId,['name'=>'setParameterValues','parameterValues'=>$init]);

            // Step 2: Tambah instance baru ke tabel MACFilter
            // addObject akan return instance number baru (mis: .3.)
            $addResult=$this->sendTask($devId,[
                'name'=>'addObject',
                'objectName'=>'InternetGatewayDevice.X_FH_Firewall.MACFilter.',
            ]);

            // Step 3: Set MAC ke instance yang baru + instance 1 dan 2 sebagai fallback
            // (GenieACS async, kita set ke beberapa index sekaligus)
            $params=[];
            foreach([1,2,3,4] as $idx){
                $base="InternetGatewayDevice.X_FH_Firewall.MACFilter.$idx";
                $params[]=["{$base}.MACAddress",$mac,'xsd:string'];
                $params[]=["{$base}.Enable",'true','xsd:boolean'];
                $params[]=["{$base}.StartTime",'00:00','xsd:string'];
                $params[]=["{$base}.EndTime",'23:59','xsd:string'];
            }
            return $this->sendTask($devId,['name'=>'setParameterValues','parameterValues'=>$params]);
        }

        // ── ZTE: InternetGatewayDevice.LANDevice.1.WLANConfiguration.{i}.MACAddressControlEnabled ──
        if($brand==='ZTE'){
            $params=[];
            foreach([1,5] as $idx){
                $base=self::WLAN_PATH.".$idx";
                $params[]=["{$base}.MACAddressControlEnabled",'true','xsd:boolean'];
                $params[]=["{$base}.AllowedMACAddresses",$mac,'xsd:string'];
            }
            return $this->sendTask($devId,['name'=>'setParameterValues','parameterValues'=>$params]);
        }

        // ── Huawei ──
        if($brand==='Huawei'){
            $params=[
                ['InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.X_HW_MACAddressFilterMode','Deny','xsd:string'],
                ['InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.X_HW_MACAddressFilter',strtoupper($mac),'xsd:string'],
            ];
            return $this->sendTask($devId,['name'=>'setParameterValues','parameterValues'=>$params]);
        }

        // ── CData ──
        if($brand==='CData'){
            $params=[];
            foreach([1,5] as $idx){
                $base=self::WLAN_PATH.".$idx";
                $params[]=["{$base}.MACAddressControlEnabled",'true','xsd:boolean'];
            }
            return $this->sendTask($devId,['name'=>'setParameterValues','parameterValues'=>$params]);
        }

        // ── Generic / fallback ──
        $params=[];
        foreach([1,2,5,6] as $idx){
            $base=self::WLAN_PATH.".$idx";
            $params[]=["{$base}.MACAddressControlEnabled",'true','xsd:boolean'];
            $params[]=["{$base}.WPS.X_BROADCOM_COM_MACDenyList",$mac,'xsd:string'];
        }
        return $this->sendTask($devId,['name'=>'setParameterValues','parameterValues'=>$params]);
    }

    // Unblock: hapus MAC dari filter table
    public function unblockClient(string $devId, array $dev, string $mac): bool {
        if(isset($dev['brand'])){$brand=$dev['brand'];}
        elseif(isset($dev['_deviceId'])){$b=$this->detectBrand($dev);$brand=$b['name']??'FiberHome';}
        else{$brand='FiberHome';}
        $mac=strtoupper(trim($mac));

        if($brand==='FiberHome'){
            // Set MAC jadi kosong di semua instance
            $params=[];
            foreach([1,2,3,4] as $idx){
                $base="InternetGatewayDevice.X_FH_Firewall.MACFilter.$idx";
                $params[]=["{$base}.MACAddress",'','xsd:string'];
                $params[]=["{$base}.Enable",'false','xsd:boolean'];
            }
            return $this->sendTask($devId,['name'=>'setParameterValues','parameterValues'=>$params]);
        }
        // Generic: disable MAC filter control
        $params=[];
        foreach([1,2,5,6] as $idx){
            $params[]=[self::WLAN_PATH.".$idx.MACAddressControlEnabled",'false','xsd:boolean'];
        }
        return $this->sendTask($devId,['name'=>'setParameterValues','parameterValues'=>$params]);
    }

    public function refresh(string $devId, array $paths=[]): bool {
        $p=$paths?:[
            'InternetGatewayDevice.LANDevice.1.WLANConfiguration.',
            'InternetGatewayDevice.WANDevice.1.',
            'InternetGatewayDevice.DeviceInfo.',
        ];
        return $this->sendTask($devId,['name'=>'getParameterValues','parameterNames'=>$p]);
    }
    public function reboot(string $devId): bool {
        return $this->sendTask($devId,['name'=>'reboot']);
    }
    public function addTag(string $id,string $t): bool {
        return $this->req('POST','/devices/'.rawurlencode($id).'/tags/'.rawurlencode($t))!==null;
    }
    public function removeTag(string $id,string $t): bool {
        return $this->req('DELETE','/devices/'.rawurlencode($id).'/tags/'.rawurlencode($t))!==null;
    }
    public function task(string $devId, array $task): bool {
        return $this->sendTask($devId,$task);
    }
    public static function fromDB(): ?self {
        try{
            $c=db()->query("SELECT * FROM genie_config WHERE is_active=1 LIMIT 1")->fetch();
            return $c?new self($c['url'],$c['username'],$c['password']):null;
        }catch(Exception $e){return null;}
    }
}
